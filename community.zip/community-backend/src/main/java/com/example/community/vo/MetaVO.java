package com.example.community.vo;

import lombok.Data;

/**
 * Description：
 * User: lmp
 * Date: 2023-10-22
 * Time: 22:59(李明浦)
 */
@Data
public class MetaVO {
    private String title;
    private String icon;
}
