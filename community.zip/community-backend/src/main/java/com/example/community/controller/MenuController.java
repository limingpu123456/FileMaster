package com.example.community.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 菜单管理 前端控制器
 * </p>
 *
 * @author admin
 * @since 2023-10-22
 */
@RestController
@RequestMapping("/menu")
public class MenuController {

}

