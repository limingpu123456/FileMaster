package com.example.community.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author admin
 * @since 2023-10-22
 */
@Controller
@RequestMapping("/role")
public class RoleController {

}

